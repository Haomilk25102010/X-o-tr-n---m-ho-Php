<?php
ini_set('memory_limit', '-1');
class myPrettyprinter extends PhpParser\PrettyPrinter\Standard
{
    private function obfuscate_string($str)
    {
      $obfuscated = '';
      for ($i = 0; $i < strlen($str); $i++) {
          $obfuscated .= sprintf("chr(%d).", ord($str[$i]));
      }
      return rtrim($obfuscated, '.');
    }


    public function pScalar_String(PhpParser\Node\Scalar\String_ $node)
    {
        $result = $this->obfuscate_string($node->value);            if (!strlen($result)) return "''";
        return  ''.$this->obfuscate_string($node->value).'';
    }


    //TODO: pseudo-obfuscate HEREDOC string
    protected function pScalar_Encapsed(PhpParser\Node\Scalar\Encapsed $node)
    {
        $result = '';
        foreach ($node->parts as $element)
        {
            if ($element instanceof PhpParser\Node\Scalar\EncapsedStringPart)
            {
                $result .=  $this->obfuscate_string($element->value);
            }
            else
            {
                $result .= '{' . $this->p($element) . '}';
            }
        }
        return ''.$result.'';
    }
}

?>